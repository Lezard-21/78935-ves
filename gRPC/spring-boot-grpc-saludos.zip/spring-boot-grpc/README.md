# spring-boot-grpc
Ejemplo de comunicación entre microservicios usando Spring Boot &amp; GRPC


Aprende mas con este video explicativo: https://www.youtube.com/watch?v=-kuHVF-pjWw
